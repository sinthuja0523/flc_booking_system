package resources.Views.Pages;

import resources.Controllers.BookingController;
import resources.Models.*;
import resources.Views.Components.Style;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class BookLessonPanel extends JPanel {
    private BookingController system;
    private JFrame parent;
    private DefaultTableModel timetableModel;
    private JTable timetableTable;
    private JRadioButton radbtn_day;
    private JRadioButton radbtn_type;
    private JComboBox<String> day_selection;

    public BookLessonPanel(BookingController system, JFrame parent) {
        this.system = system;
        this.parent = parent;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        createUserInterface();
    }

    private void createUserInterface() {
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JComboBox<Member> memberCombo = new JComboBox<>();
        for (Member m : system.getAllMembers()) {
            memberCombo.addItem(m);
        }

        radbtn_day = new JRadioButton("Filter by Day");
        radbtn_type = new JRadioButton("Filter by Type");
        day_selection = new JComboBox<>(new String[] { "Saturday", "Sunday" });

        ButtonGroup bg = new ButtonGroup();
        bg.add(radbtn_day);
        bg.add(radbtn_type);
        radbtn_day.setSelected(true);

        radbtn_day.addActionListener(e -> {
            day_selection.removeAllItems();
            day_selection.addItem("Saturday");
            day_selection.addItem("Sunday");
        });

        radbtn_type.addActionListener(e -> {
            day_selection.removeAllItems();
            day_selection.addItem("Yoga");
            day_selection.addItem("Zumba");
            day_selection.addItem("Aquacise");
            day_selection.addItem("Box Fit");
        });

        JButton search_button = new JButton("Search Lessons");
        Style.changeButtonStyle(search_button);

        filterPanel.add(new JLabel("Member:"));
        filterPanel.add(memberCombo);
        filterPanel.add(radbtn_day);
        filterPanel.add(radbtn_type);
        filterPanel.add(day_selection);
        filterPanel.add(search_button);

        // String[] columns = {"ID", "Exercise", "Day", "Time", "Price",
        // "Availability"};
        String[] columns = { "ID", "Exercise", "Schedule", "Time", "Price", "Availability" };

        timetableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        timetableTable = new JTable(timetableModel);
        JScrollPane scrollPane = new JScrollPane(timetableTable);

        timetableTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus,
                    int row, int column) {

                Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                // Get lesson ID from table
                String lessonId = (String) table.getValueAt(row, 0);

                // Find lesson object
                Lesson lesson = system.getLessonById(lessonId);

                if (lesson != null) {
                    int week = lesson.getWeekend(); // week number (1–4)

                    if (!isSelected) {
                        switch (week) {
                            case 1:
                                c.setBackground(new Color(220, 235, 255)); // light blue
                                break;
                            case 2:
                                c.setBackground(new Color(220, 255, 220)); // light green
                                break;
                            case 3:
                                c.setBackground(new Color(255, 255, 200)); // light yellow
                                break;
                            case 4:
                                c.setBackground(new Color(255, 220, 230)); // light pink
                                break;
                            default:
                                c.setBackground(Color.WHITE);
                        }
                    }
                }

                return c;
            }
        });

        search_button.addActionListener(e -> refreshLessonTable());

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btn_book_lesson = new JButton("Book Selected Lesson");
        Style.changeButtonStyle(btn_book_lesson);

        btn_book_lesson.addActionListener(e -> {
            int row = timetableTable.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(parent, "Please select a lesson to book.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            String lessonId = (String) timetableModel.getValueAt(row, 0);
            Lesson lesson = system.getLesson(lessonId);
            Member member = (Member) memberCombo.getSelectedItem();

            String result = system.bookLesson(member, lesson);
            if (result.startsWith("Success")) {
                JOptionPane.showMessageDialog(parent, result, "Success", JOptionPane.INFORMATION_MESSAGE);
                search_button.doClick();
            } else {
                JOptionPane.showMessageDialog(parent, result, "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        bottomPanel.add(btn_book_lesson);

        add(filterPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    public void refreshLessonTable() {
        timetableModel.setRowCount(0);

        String criteria = (String) day_selection.getSelectedItem();
        List<Lesson> lessons;

        if (criteria == null) {
            return;
        }

        if (radbtn_day.isSelected()) {
            lessons = system.getLessonsByDay(criteria);
        } else {
            lessons = system.getLessonsByType(criteria);
        }

        for (Lesson l : lessons) {
            int booked = l.getCurrentAttendeesCount();
            int capacity = l.getCapacity();

            String status;

            if (booked == capacity) {
                status = "Full";
            } else {
                status = (capacity - booked) + " spots left";
            }
            String[] months = { "Jan", "Feb", "Mar" };
            String schedule = months[l.getMonth() - 1] + " Week " + l.getWeekend();

            timetableModel.addRow(new Object[] {
                    l.getId(),
                    l.getExerciseType(),
                    schedule,
                    l.getTime(),
                    "£" + l.getPrice(),
                    status
            });
        }
    }
}